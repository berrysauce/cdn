import typer
import requests
import base64
import json
from tkinter import Tk
from tkinter.filedialog import askopenfilename

app = typer.Typer()
#server = "http://usa.cdn.brry.cc"

@app.command()
def upload(server: str):
    typer.echo("Choose an image to upload")
    Tk().withdraw()
    image_path = askopenfilename()
    typer.secho("Uploading image...", fg=typer.colors.BRIGHT_BLUE)
    
    try:
        with open(image_path, "rb") as image_file:
            image = base64.b64encode(image_file.read())
        data = json.dumps({"image":image.decode("utf-8")})
        r = requests.post(server+"/upload", data=data)
    except:
        typer.secho("Error - failed to convert/upload image", fg=typer.colors.RED)
        return
    
    if r.status_code == 200:
        typer.secho("Image uploaded - Link: "+server+"/image/"+r.text.replace("\"", ""), fg=typer.colors.GREEN)
        #typer.echo(f"Image uploaded - Link: "+server+"/image/"+r.text.replace("\"", ""))
    else:
        typer.secho(f"Error - got response {r.status_code}", fg=typer.colors.RED)


@app.command()
def delete():
    typer.echo(f"This command is WIP")