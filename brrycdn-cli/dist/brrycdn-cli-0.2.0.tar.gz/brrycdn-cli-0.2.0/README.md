# brryCDN CLI
This CLI can be used to upload images to the brryCDN.